package com.example.spring01.service;

import org.jfree.chart.JFreeChart;

public interface JFreeChartService {
	public JFreeChart createChart();
}

