package com.example.spring01.service;

import org.json.simple.JSONObject;

public interface GoogleChartService {
	public JSONObject getChartData();
}

