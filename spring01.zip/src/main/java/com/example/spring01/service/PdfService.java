package com.example.spring01.service;

public interface PdfService {
	public String createPdf();
}
